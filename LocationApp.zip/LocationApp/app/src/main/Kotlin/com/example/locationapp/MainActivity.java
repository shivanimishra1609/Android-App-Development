package com.example.locationapp;

import android.app.Activity;

public class MainActivity extends Activity {
}
