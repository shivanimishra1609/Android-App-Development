package com.example.locationsubmissionapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.happcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.OnCompleteListener
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView



class MainActivity : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var btnGetLocation: Button
    private lateinit var btnSelectLocation: Button
    private lateinit var btnSubmit: Button

    private var latitude: Double = 0.0
    private var longitude: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        btnGetLocation = findViewById(R.id.btnGetLocation)
        btnSelectLocation = findViewById(R.id.btnSelectLocation)
        btnSubmit = findViewById(R.id.btnSubmit)

        // Initialize FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Get Current Location
        btnGetLocation.setOnClickListener {
            getCurrentLocation()
        }

        // Select Location Manually
        btnSelectLocation.setOnClickListener {
            val intent = Intent(this, MapActivity::class.java)
            startActivityForResult(intent, 100)
        }

        // Submit Location
        btnSubmit.setOnClickListener {
            if (latitude != 0.0 && longitude != 0.0) {
                sendLocationToApi(latitude, longitude)
            } else {
                Toast.makeText(this, "No location selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Get the user's current location using GPS
    private fun getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Request location permissions if not granted
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }

        fusedLocationClient.lastLocation.addOnCompleteListener(OnCompleteListener<Location> { task ->
            val location: Location? = task.result
            if (location != null) {
                latitude = location.latitude
                longitude = location.longitude
                Toast.makeText(this, "Location fetched: $latitude, $longitude", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Unable to get current location", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Send the selected location to an API endpoint (you'll implement this part)
    private fun sendLocationToApi(latitude: Double, longitude: Double) {
        val locationRequest = LocationRequest(latitude.toString(), longitude.toString())

        // Make the API request asynchronously using Retrofit
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitClient.apiService.submitLocation(locationRequest)

                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@MainActivity, "Location submitted successfully!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, "Error: ${response.message()}", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    // Handle the result from MapActivity (manual location selection)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 100 && resultCode == RESULT_OK) {
            val selectedLatitude = data?.getDoubleExtra("latitude", 0.0) ?: 0.0
            val selectedLongitude = data?.getDoubleExtra("longitude", 0.0) ?: 0.0

            if (selectedLatitude != 0.0 && selectedLongitude != 0.0) {
                latitude = selectedLatitude
                longitude = selectedLongitude
                Toast.makeText(this, "Location selected: $latitude, $longitude", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
